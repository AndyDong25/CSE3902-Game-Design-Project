﻿namespace CSE3902_Sprint2.Controller
{
    public interface IController
    {
        void Update();
    }
}
