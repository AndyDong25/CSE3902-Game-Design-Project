﻿using Microsoft.Xna.Framework.Content;

namespace CSE3902_Sprint2
{
    public interface ISpriteFactory
    {
        void LoadAllResources(ContentManager content);
    }
}
