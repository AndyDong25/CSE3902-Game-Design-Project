﻿namespace CSE3902_Sprint2.Commands
{
    public interface ICommand
    {
        void Execute(); 
    }
}